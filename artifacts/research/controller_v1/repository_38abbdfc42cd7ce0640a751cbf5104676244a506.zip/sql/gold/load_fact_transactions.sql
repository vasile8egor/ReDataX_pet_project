WITH transactions AS (
    SELECT
        transaction_id,
        account_id,
        tx_timestamp,
        amount,
        currency,
        merchant_name,
        bronze_loaded_at,
        ROW_NUMBER() OVER (
            PARTITION BY transaction_id
            ORDER BY bronze_loaded_at DESC
        ) AS row_num
    FROM silver.v_transactions
)
SELECT
    transaction_id,
    account_id,
    tx_timestamp,
    amount,
    currency,
    merchant_name,
    bronze_loaded_at
FROM transactions
WHERE row_num = 1;
