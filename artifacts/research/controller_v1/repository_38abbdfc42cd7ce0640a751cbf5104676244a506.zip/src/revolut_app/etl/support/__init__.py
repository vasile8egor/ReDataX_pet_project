"""Shared ETL support utilities."""
